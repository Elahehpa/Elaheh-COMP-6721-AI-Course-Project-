# COMP-6721-AI-Course-Project-
Team - G <br>
Project - Garbage Image Classification using Deep Learning
